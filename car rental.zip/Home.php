<?php
include "connectDB.php";

$query = mysqli_query($conn, "SELECT * FROM `car` WHERE 1  ");


while ($row = mysqli_fetch_assoc($query)) {
  // Append only the `player` column rather than the whole $row (which is an array)
  $result[] = $row;
}



$count = 0;

foreach ($query as $row) {
  $count++;
}
$numrows = ceil($count / 4);



?>


<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="adminstyle.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

  <script src="adminscript.js"></script>



  <title>Home</title>
</head>

<body>
  <div class="header topnav" id="myHeader">
    <a class="active" href="home.php">Home</a>
    <a href="addcar.php">Add Car</a>
    <a href="addoffice.php">Add Office</a>
    <a href="customers.php">Customers</a>
    <a href="rentedcars.php">Rented Cars</a>
    <a href="searchcars.php">Cars</a>
    <a href="reports.php">Reports</a>
    <a href="complaints.php">Complaints</a>
  </div>


  <div class="content ">

    <br>
    <?php
    $temp = 0;
    for ($i = 0; $i < $numrows; $i++) { ?>
      <div class="row">
        <?php
        for ($j = $temp; $j < $temp + 4; $j++) {

          $src = $result[$j]['image'];


        ?>

          <div class="column">
            <div class="card">

              <img onclick="document.getElementById('<?php echo $j; ?>').style.display='block'" class=" w3-modal-content w3-animate-zoom" src="<?php echo $src ?>" alt="No Image Found" style=" width: 100%; height: 150px;">
              <p><?php echo $result[$j]['brand'];
                  echo " ";
                  echo $result[$j]['name'];
                  ?>
                  
                  
              </p>
              <p class="price"><?php echo $result[$j]['rate'];
                                echo '  $/day' ?>
              </p>
              <p><?php echo 'Engine: ';
                  echo $result[$j]['capacity'];
                  echo " cc"; ?>
                  <br>
                  <?php echo $result[$j]['status']; ?>

              </p>

              <p>
                
              <button><a href="updateStatus.php?car=<?php echo $result[$j]['carid'] ?>">Change Status</a></button>
              </p>
               



              <div id="<?php echo $j; ?>" class="w3-modal" onclick="this.style.display='none'">
                <span class="w3-button w3-hover-red w3-xlarge w3-display-topright">&times;</span>

                <div class="w3-modal-content w3-animate-zoom">
                  <img src="<?php echo $src ?>" alt="<?php echo $j ?>" style="width:100%">
                </div>
              </div>
              

            </div>
          </div>

        <?php
          if ($j == $count - 1) break;
        }

        $temp += 4;
        ?>
      </div>





      <br>
    <?php } ?>



  </div>

  <br></br>

  <div class="footer">
    <p>Footer</p>
  </div>



</body>

</html>