<?php
    //session_start();
    include "config.php";
                        
    $uname = $_POST['name'];
    $password = $_POST['password']; 
    $hashed_password = md5($password);


    $data = array();
    $sql_query = "SELECT * FROM admin WHERE username='".$uname."'"; 
    $sql_query = "SELECT username,password,accessNum FROM admin WHERE username='".$uname."'"

    . "UNION\n"

    . "SELECT username,password,accessNum FROM customer WHERE username = '".$uname."'";
    $result = mysqli_query($con,$sql_query);
    $row = mysqli_fetch_array($result);

    


    if(mysqli_num_rows($result)>0){
            if ($hashed_password == $row['password']){
                $data['status'] = $row['accessNum'];
        }else{
            $data['status'] = 'wr';
        }
    }else{
        $data['status'] = 'no';
    }
    echo json_encode($data);
    exit();
                        
?>