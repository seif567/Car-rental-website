<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="adminstyle.css">
    <script src="adminscript.js"></script>



    <title>Home</title>
  </head>
  <body>
  <div class="header topnav"  id="myHeader">
  <a  href="home.php">Home</a>
  <a href="addcar.php">Add Car</a>
  <a href="addoffice.php">Add Office</a>
  <a href="customers.php">Customers</a>
  <a href="rentedcars.php">Rented Cars</a>
  <a href="searchcars.php">Cars</a>
  <a href="reports.php">Reports</a>
  <a class="active" href="complaints.php">Complaints</a>
</div>


<div class = "content "style=" font-size: 76px">
complaints </div>

<br></br>

<div class="footer">
  <p>Footer</p>
</div>



  </body>
</html>