<?php
include "connectDB.php";

$type = $_POST['report'];
$startDate = $_POST['startdate'];
$endDate = $_POST['enddate'];



if ($type == 'revenue'){

    $query = mysqli_query($conn,"SELECT * FROM payment
     WHERE payment_date > '$startDate' AND payment_date < '$endDate'" );

    

  }

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="adminstyle.css">
    <script src="adminscript.js"></script>



    <title>Home</title>
  </head>
  <body>
  <div class="header topnav"  id="myHeader">
  <a  href="home.php">Home</a>
  <a href="addcar.php">Add Car</a>
  <a href="addoffice.php">Add Office</a>
  <a href="customers.php">Customers</a>
  <a href="rentedcars.php">Rented Cars</a>
  <a href="searchcars.php">Cars</a>
  <a  class="active" href="reports.php">Reports</a>
  <a href="complaints.php">Complaints</a>
</div>


<div class= "content "style=" font-size:35px">

<br>
<div class="container" style="padding: 5%; overflow: auto;">
                                <form action="" method="post" class="row">
                                    <table class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <tr>


                                            <td style="font-size:1.1em; text-align:center;"> Payment ID</td>
                                            <td style="font-size:1.1em; text-align:center;"> customer ID</td>
                                            <td style="font-size:1.1em;text-align:center;"> Car ID </td>
                                            <td style="font-size:1.1em; text-align:center;"> Rent Date </td>
                                            <td style="font-size:1.1em;text-align:center;"> Amount </td>
                                            <td style="font-size:1.1em;text-align:center;"> Payment date </td>
                                            <td style="font-size:1.1em;text-align:center;"> Payment status </td>
                                            <td style="font-size:1.1em;text-align:center;"> Payment Type </td>
                                        </tr>

                                      <?php

                            $count = 0;
                            $totalrevenue=0;

                            foreach($query as $row){
                             $count++;
                             if($row["payment_status"] == 1){
                                $totalrevenue += $row['amount'];
                             }
                             $total += $row['amount'];
                            ?>
                            

                            <tr style="overflow: auto; font-size:0.8em; border-bottom: 1px black dashed; text-align: center; color: black;">
                 <td style="background-color:White;"><?php echo $row["payment_id"]; ?></td>
                 <td style="background-color:White;"><?php echo $row["cid"]; ?></td>
                 <td style="background-color:White;"><?php echo $row["carid"]; ?></td>
                 <td style="background-color:White;"><?php echo $row["rentdate"]; ?></td>
                 <td style="background-color:White;"><?php echo $row["amount"]; ?></td>
                 <td style="background-color:White;"><?php echo $row["payment_date"]; ?></td>
                 <td style="background-color:White;"><?php echo $row["payment_status"]; ?></td>
                 <td style="background-color:White;"><?php echo $row["payment_type"]; ?></td>
                 
             </tr>

                            <?php
                            }
                            ?>
                            </table>
                            <span style="font-size:38"> Total revenue in that time period payed = <?php echo $totalrevenue?></span>
                            <span style="font-size:38"> Total revenue in that time period = <?php echo $total?></span>
                          </form>


<br></br>

  </body>
</html>