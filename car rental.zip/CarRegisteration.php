<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
		<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
		
		<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
		<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
		<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
		<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
		<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
		<link rel="stylesheet" type="text/css" href="css/util.css">
		<link rel="stylesheet" type="text/css" href="css/main.css">
		<title>Registration</title>
		<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
	</head>
	<body>
		<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100 p-t-30 p-b-50">
				<span class="login100-form-title p-b-41">
				
			<br>
			Please Enter the car information you want to add to the system
		</span>
	        <form class="login100-form validate-form p-b-33 p-t-5"  method="POST" id="LogIn" 	> 
	        <div class="wrap-input100 validate-input" >
   				<input class="input100" type="text" name="name" id="name" placeholder="Name">
				<span class="focus-input100" data-placeholder="&#xe82a;"></span>
			</div> 

	        <div class="wrap-input100 validate-input" >
   				<input class="input100" type="number" name="year" id="year" placeholder="Model Year">
				<span class="focus-input100" data-placeholder="&#xe82a;"></span>
			</div>

			<div class="wrap-input100 validate-input" >
   				<input class="input100" type="text" name="type" id="type" placeholder="Car Type">
				<span class="focus-input100" data-placeholder="&#xe82a;"></span>
			</div>

			<div class="wrap-input100 validate-input" >
				<input class="input100" type="text" name="brand" id="brand" placeholder="Manufacturer">
				<span class="focus-input100" data-placeholder="&#xe80f;"></span>
			</div>

			<div class="wrap-input100 validate-input" >
				<input class="input100" type="text" name="color" id="color" placeholder="Car color">
				<span class="focus-input100" data-placeholder="&#xe80f;"></span>
			</div>

			<div class="wrap-input100 validate-input" >
				<input class="input100" type="text" name="capacity" id="capacity" placeholder="Capacity">
				<span class="focus-input100" data-placeholder="&#xe80f;"></span>
			</div>

			<div class="wrap-input100 validate-input" >
				<input class="input100" type="text" name="plate" id="plate" placeholder="PLate Numbers">
				<span class="focus-input100" required="required" data-placeholder="&#xe80f;"></span>
			</div>
			<div class="wrap-input100 validate-input" >
				<input class="input100" type="number" name="rate" id="rate" placeholder="Rate per day">
				<span class="focus-input100" required="required" data-placeholder="&#xe80f;"></span>
			</div>

			<div class="wrap-input100 validate-input" >
				<input class="input100" type="number" name="location" id="location" placeholder="Location Id">
				<span class="focus-input100" required="required" data-placeholder="&#xe80f;"></span>
			</div>




			<form action="upload.php" method="post" enctype="multipart/form-data" id="form">
			    <label>Select Image File:</label>
			    <input type="file" name="image">
		    	<input type="submit" name="submit" value="Upload">
			</form>





				<span class="focus-input100" data-placeholder="&#xe80f;"></span>
			<div class="container-login100-form-btn m-t-32">
				<button class="login100-form-btn" id="ok">
							Login
				</button>
			</div>     
			<br><br>   
	        Already have an account <a href="index.php">Log In</a> 
	     

	           
	    </form>
	    </div>	    
	    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
		 <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
			<script src="vendor/animsition/js/animsition.min.js"></script>
			<script src="vendor/bootstrap/js/popper.js"></script>
			<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
			<script src="vendor/select2/select2.min.js"></script>
			<script src="vendor/daterangepicker/moment.min.js"></script>
			<script src="vendor/daterangepicker/daterangepicker.js"></script>
			<script src="vendor/countdowntime/countdowntime.js"></script>
			<script src="js/main.js"></script>
  	    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
  	    <script type="text/javascript">
  	    	function validate(){

  	    		//var formData = new FormData(form);



  	    		var name =$('#name').val(); 
				var year =$('#year').val();
				var type=$('#type').val();
				var brand=$('#brand').val();
				var color=$('#color').val();
				var capacity=$('#capacity').val();
				var plate=$('#plate').val();
				var rate=$('#rate').val();
				var location=$('#location').val();

				event.preventDefault();

				if(name.length==0){
					alert('Enter the name of the car');
					return false;
				}else
				if(year.length==0){
					alert('Enter the year of the car');
					return false;
				}
				if(type.length==0){
					alert('Enter the type of the car');
					return false;
				}
				else if(brand.length==0){
					alert('Enter the brand of the car');
					return false;
				}
				else if(color.length==0){
					alert('Enter the color of the car');
					return false;
				}
				else if(capacity.length==0){
					alert('Enter the capacity of the car');
					return false;
				}
				else if(plate.length==0){
					alert('Enter the plate number of the car');
					return false;
				}
				else if(rate.length==0){
					alert('Enter the rate of the car per day');
					return false;
				}
				else if(location.length==0){
					alert('Enter the location of the car');
					return false;
				}
				

				$.ajax({
						method: 'POST',
					    url: 'InputCar.php',
					    dataType: 'json',
					    data: new FormData(this),



					    /*{


					    	/*name:name,
					    	year:year,
					    	type:type,
					    	brand:brand,
					    	color:color,
					    	capacity:capacity,
					    	plate:plate,
					    	rate:rate,
					    	location:location,
					    },*/
					    timeout: 600,
					    success: function(data){
					        if(data.status == "ok"){
					        	var queryString = "?name=" + name ;
			                    location.href = "Customers.php" + queryString; 
						
							}else if (data.status == "found"){
								alert("Email Already registered try logging in");
							}else{
								alert("ERROR 404 NOT FOUND ");
							}
						},
					     error: function(XMLHttpRequest, textStatus, errorThrown) { 
						        alert("Status: " + textStatus); 
						        alert("Error: " + errorThrown); 
						}
					    
					});	

		

  	    	}
  	    
  	    	let btn = document.getElementById("ok");
		    btn.addEventListener('click', event => {
		      validate();
		    });


  	    </script>


	</body>

</html>