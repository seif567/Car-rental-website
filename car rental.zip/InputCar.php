<?php
include "connectDB.php";



$brand = $_POST['Brand'];
$name = $_POST['Name'];
$modelYear = $_POST['ModelYear'];
$plate =$_POST['plate'];
$capacity = $_POST['capacity'];
$color = $_POST['color'];
$rate = $_POST['rate'];
$officeid = $_POST['officeid'];
$type = $_POST['Type'];
$status = $_POST['status'];


$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 0;
  }
}

// Check if file already exists
if (file_exists($target_file)) {
  echo "Sorry, file already exists.";
  $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
  echo "Sorry, your file is too large.";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}

$query = mysqli_query($conn, "INSERT INTO `car`( `NAME`, `model_year`, `TYPE`, `brand`, `color`, `capacity`, `plate_number`, `rate`, `STATUS`,`reserved`, `officeid`,`image`) 
VALUES ('$name','$modelYear','$type','$brand','$color','$capacity','$plate','$rate','$status',0,'$officeid','$target_file')");

if($query) {echo "success";}





?>